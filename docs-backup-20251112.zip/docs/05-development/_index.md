---
title: "Development"
weight: 5
bookCollapseSection: true
bookFlatSection: false
---

# Development

Documentation for contributors and developers working on pass-cli.

This section covers development setup, CI/CD, release processes, and project maintenance.
