---
title: "Getting Started"
weight: 1
bookCollapseSection: false
bookFlatSection: false
---

# Getting Started

New to pass-cli? Start here to get up and running quickly.

This section covers installation, initial setup, and your first steps with pass-cli.
